# SOP-001: Sample Processing Procedure

**Document Type:** Standard Operating Procedure
**Version:** 1.0
**Effective Date:** 2025-10-26
**Owner:** Quality Assurance

## Purpose

This SOP describes the standard procedure for processing biological samples in compliance with good laboratory practices (GLP).

## Scope

This procedure applies to all personnel handling biological samples in the laboratory.

## Responsibilities

- **Laboratory Technicians**: Execute sample processing according to this SOP
- **QA Manager**: Review and approve SOP updates
- **Laboratory Supervisor**: Ensure staff training and compliance

## Procedure

### 4.1 Sample Receipt

1. Verify sample identification matches the requisition form
2. Check sample integrity (proper container, no leakage)
3. Record receipt time and temperature in lab notebook
4. Store at appropriate temperature (2-8°C for biological samples)

### 4.2 Sample Processing

1. Allow samples to reach room temperature if frozen
2. Label processing tubes with unique sample ID
3. Process samples within 2 hours of removal from storage
4. Document any deviations from standard procedure

### 4.3 Quality Control

- Process control samples alongside test samples
- Verify instrument calibration before processing
- Review results for anomalies

## References

- ISO 15189:2022 - Medical laboratories
- FDA 21 CFR Part 58 - Good Laboratory Practice

## Revision History

| Version | Date | Changes | Approved By |
|---------|------|---------|-------------|
| 1.0 | 2025-10-26 | Initial release | [Pending] |
