# QMS Test Repository

This is a test repository for AtomicQMS AI Assistant.

## Testing the AI Assistant

To test the AI assistant, create an issue or pull request and mention `@qms-assistant` in a comment.

### Example Commands

- `@qms-assistant Can you help review this document?`
- `@qms-assistant Check this SOP for compliance issues`
- `@qms-assistant What are the requirements for this change?`

## Sample Documents

See the `docs/` directory for sample QMS documents.
